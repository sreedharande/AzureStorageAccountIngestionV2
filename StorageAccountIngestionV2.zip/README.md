# AzureStorageAccountIngestionV2
Ingest anything from Storage Account 
